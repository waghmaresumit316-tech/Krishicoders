"use node";

import { internalAction, internalMutation, internalQuery } from "./_generated/server";
import { v } from "convex/values";
import { internal } from "./_generated/api";
import OpenAI from "openai";

const openai = new OpenAI({
  baseURL: process.env.CONVEX_OPENAI_BASE_URL,
  apiKey: process.env.CONVEX_OPENAI_API_KEY,
});

export const analyzeCropImage = internalAction({
  args: { imageRecordId: v.id("cropImages") },
  handler: async (ctx, args) => {
    const imageRecord = await ctx.runQuery(internal.images.getImageRecord, {
      imageRecordId: args.imageRecordId,
    });

    if (!imageRecord) {
      throw new Error("Image record not found");
    }

    try {
      // Update status to processing
      await ctx.runMutation(internal.images.updateImageAnalysisStatus, {
        imageRecordId: args.imageRecordId,
        status: "processing",
      });

      // Simulate AI analysis (in real implementation, this would call your trained model)
      const analysisPrompt = `
        Analyze this crop image for:
        1. Disease detection and identification
        2. Crop health assessment
        3. Stress indicators
        4. Growth stage evaluation
        5. Recommendations for treatment

        Provide a detailed analysis in JSON format with:
        - diseaseDetected: boolean
        - diseases: array of {name, confidence, severity, affectedArea}
        - healthScore: number (0-100)
        - stressLevel: string (low/medium/high)
        - recommendations: array of strings
      `;

      const response = await openai.chat.completions.create({
        model: "gpt-4.1-nano",
        messages: [
          {
            role: "user",
            content: analysisPrompt,
          },
        ],
      });

      // Parse AI response (this is a simulation - replace with actual model results)
      const mockAnalysis = {
        diseaseDetected: Math.random() > 0.7,
        diseases: [
          {
            name: "Leaf Blight",
            confidence: 0.85,
            severity: "medium",
            affectedArea: 15.5,
          },
        ],
        healthScore: Math.floor(Math.random() * 40) + 60,
        stressLevel: ["low", "medium", "high"][Math.floor(Math.random() * 3)],
        recommendations: [
          "Apply fungicide treatment",
          "Increase irrigation frequency",
          "Monitor for pest activity",
        ],
      };

      // Update image record with analysis results
      await ctx.runMutation(internal.images.updateImageAnalysisResults, {
        imageRecordId: args.imageRecordId,
        results: mockAnalysis,
      });

      // Create alert if disease detected
      if (mockAnalysis.diseaseDetected) {
        await ctx.runMutation(internal.alerts.createDiseaseAlert, {
          fieldId: imageRecord.fieldId,
          farmerId: imageRecord.farmerId,
          diseases: mockAnalysis.diseases,
        });
      }

    } catch (error) {
      console.error("AI analysis failed:", error);
      await ctx.runMutation(internal.images.updateImageAnalysisStatus, {
        imageRecordId: args.imageRecordId,
        status: "failed",
      });
    }
  },
});
