import { query, mutation, internalMutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

export const getAlerts = query({
  args: { 
    fieldId: v.optional(v.id("fields")),
    unreadOnly: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }

    const farmer = await ctx.db
      .query("farmers")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!farmer) {
      return [];
    }

    let query = ctx.db
      .query("alerts")
      .withIndex("by_farmer", (q) => q.eq("farmerId", farmer._id));

    if (args.fieldId) {
      query = ctx.db
        .query("alerts")
        .withIndex("by_field", (q) => q.eq("fieldId", args.fieldId!));
    }

    const alerts = await query.order("desc").collect();

    if (args.unreadOnly) {
      return alerts.filter(alert => !alert.isRead);
    }

    return alerts;
  },
});

export const markAlertAsRead = mutation({
  args: { alertId: v.id("alerts") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("User not authenticated");
    }

    const alert = await ctx.db.get(args.alertId);
    if (!alert) {
      throw new Error("Alert not found");
    }

    const farmer = await ctx.db.get(alert.farmerId);
    if (!farmer || farmer.userId !== userId) {
      throw new Error("Unauthorized");
    }

    await ctx.db.patch(args.alertId, { isRead: true });
  },
});

export const resolveAlert = mutation({
  args: { alertId: v.id("alerts") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("User not authenticated");
    }

    const alert = await ctx.db.get(args.alertId);
    if (!alert) {
      throw new Error("Alert not found");
    }

    const farmer = await ctx.db.get(alert.farmerId);
    if (!farmer || farmer.userId !== userId) {
      throw new Error("Unauthorized");
    }

    await ctx.db.patch(args.alertId, {
      isResolved: true,
      resolvedAt: Date.now(),
    });
  },
});

export const createDiseaseAlert = internalMutation({
  args: {
    fieldId: v.id("fields"),
    farmerId: v.id("farmers"),
    diseases: v.array(v.object({
      name: v.string(),
      confidence: v.number(),
      severity: v.string(),
      affectedArea: v.number(),
    })),
  },
  handler: async (ctx, args) => {
    const field = await ctx.db.get(args.fieldId);
    if (!field) {
      throw new Error("Field not found");
    }

    const diseaseNames = args.diseases.map(d => d.name).join(", ");
    const maxSeverity = args.diseases.reduce((max, d) => 
      d.severity === "high" ? "high" : 
      d.severity === "medium" && max !== "high" ? "medium" : max, 
      "low"
    );

    await ctx.db.insert("alerts", {
      farmerId: args.farmerId,
      fieldId: args.fieldId,
      type: "disease",
      severity: maxSeverity,
      title: "Disease Detected",
      message: `Diseases detected in ${field.name}: ${diseaseNames}. Immediate attention required.`,
      isRead: false,
      isResolved: false,
      createdAt: Date.now(),
    });
  },
});

export const createIrrigationAlert = internalMutation({
  args: {
    fieldId: v.id("fields"),
    farmerId: v.id("farmers"),
    moistureLevel: v.number(),
    threshold: v.number(),
  },
  handler: async (ctx, args) => {
    const field = await ctx.db.get(args.fieldId);
    if (!field) {
      throw new Error("Field not found");
    }

    await ctx.db.insert("alerts", {
      farmerId: args.farmerId,
      fieldId: args.fieldId,
      type: "irrigation",
      severity: args.moistureLevel < (args.threshold * 0.5) ? "high" : "medium",
      title: "Irrigation Required",
      message: `Field ${field.name} needs water. Current moisture: ${args.moistureLevel}%, Threshold: ${args.threshold}%`,
      isRead: false,
      isResolved: false,
      createdAt: Date.now(),
      actionRequired: {
        type: "irrigation",
        parameters: {
          duration: 30, // minutes
          amount: 100, // liters
        },
      },
    });
  },
});
