import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

export const createField = mutation({
  args: {
    name: v.string(),
    area: v.number(),
    cropType: v.string(),
    plantingDate: v.number(),
    expectedHarvestDate: v.number(),
    coordinates: v.object({
      lat: v.number(),
      lng: v.number(),
    }),
    soilType: v.string(),
    irrigationType: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("User not authenticated");
    }

    const farmer = await ctx.db
      .query("farmers")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!farmer) {
      throw new Error("Farmer profile not found");
    }

    return await ctx.db.insert("fields", {
      farmerId: farmer._id,
      ...args,
    });
  },
});

export const getFields = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }

    const farmer = await ctx.db
      .query("farmers")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!farmer) {
      return [];
    }

    return await ctx.db
      .query("fields")
      .withIndex("by_farmer", (q) => q.eq("farmerId", farmer._id))
      .collect();
  },
});

export const getFieldById = query({
  args: { fieldId: v.id("fields") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return null;
    }

    const field = await ctx.db.get(args.fieldId);
    if (!field) {
      return null;
    }

    const farmer = await ctx.db.get(field.farmerId);
    if (!farmer || farmer.userId !== userId) {
      return null;
    }

    return field;
  },
});
