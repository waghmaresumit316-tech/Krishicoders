import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

export const addSensorReading = mutation({
  args: {
    sensorId: v.string(),
    fieldId: v.id("fields"),
    value: v.number(),
    unit: v.string(),
    sensorType: v.string(),
  },
  handler: async (ctx, args) => {
    const sensor = await ctx.db
      .query("sensors")
      .withIndex("by_sensor_id", (q) => q.eq("sensorId", args.sensorId))
      .unique();

    if (!sensor) {
      throw new Error("Sensor not found");
    }

    const reading = await ctx.db.insert("sensorReadings", {
      sensorId: sensor._id,
      fieldId: args.fieldId,
      timestamp: Date.now(),
      value: args.value,
      unit: args.unit,
      sensorType: args.sensorType,
    });

    // Update sensor last reading
    await ctx.db.patch(sensor._id, {
      lastReading: Date.now(),
    });

    return reading;
  },
});

export const getLatestSensorReadings = query({
  args: { fieldId: v.id("fields") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }

    const field = await ctx.db.get(args.fieldId);
    if (!field) {
      return [];
    }

    const farmer = await ctx.db.get(field.farmerId);
    if (!farmer || farmer.userId !== userId) {
      return [];
    }

    const sensors = await ctx.db
      .query("sensors")
      .withIndex("by_field", (q) => q.eq("fieldId", args.fieldId))
      .collect();

    const readings = [];
    for (const sensor of sensors) {
      const latestReading = await ctx.db
        .query("sensorReadings")
        .withIndex("by_sensor", (q) => q.eq("sensorId", sensor._id))
        .order("desc")
        .first();

      if (latestReading) {
        readings.push({
          sensor,
          reading: latestReading,
        });
      }
    }

    return readings;
  },
});

export const getSensorHistory = query({
  args: {
    fieldId: v.id("fields"),
    sensorType: v.string(),
    hours: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }

    const field = await ctx.db.get(args.fieldId);
    if (!field) {
      return [];
    }

    const farmer = await ctx.db.get(field.farmerId);
    if (!farmer || farmer.userId !== userId) {
      return [];
    }

    const hours = args.hours || 24;
    const startTime = Date.now() - (hours * 60 * 60 * 1000);

    return await ctx.db
      .query("sensorReadings")
      .withIndex("by_field_and_time", (q) => 
        q.eq("fieldId", args.fieldId).gte("timestamp", startTime)
      )
      .filter((q) => q.eq(q.field("sensorType"), args.sensorType))
      .order("desc")
      .collect();
  },
});
