import { mutation, query, action, internalQuery, internalMutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";
import { api, internal } from "./_generated/api";

export const generateUploadUrl = mutation({
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("User not authenticated");
    }
    return await ctx.storage.generateUploadUrl();
  },
});

export const saveCropImage = mutation({
  args: {
    fieldId: v.id("fields"),
    imageId: v.id("_storage"),
    imageType: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("User not authenticated");
    }

    const farmer = await ctx.db
      .query("farmers")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!farmer) {
      throw new Error("Farmer profile not found");
    }

    const field = await ctx.db.get(args.fieldId);
    if (!field || field.farmerId !== farmer._id) {
      throw new Error("Field not found or unauthorized");
    }

    const imageRecord = await ctx.db.insert("cropImages", {
      fieldId: args.fieldId,
      farmerId: farmer._id,
      imageId: args.imageId,
      imageType: args.imageType,
      captureDate: Date.now(),
      analysisStatus: "pending",
    });

    // Schedule AI analysis
    await ctx.scheduler.runAfter(0, internal.ai.analyzeCropImage, {
      imageRecordId: imageRecord,
    });

    return imageRecord;
  },
});

export const getCropImages = query({
  args: { fieldId: v.id("fields") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }

    const farmer = await ctx.db
      .query("farmers")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!farmer) {
      return [];
    }

    const images = await ctx.db
      .query("cropImages")
      .withIndex("by_field", (q) => q.eq("fieldId", args.fieldId))
      .order("desc")
      .collect();

    return Promise.all(
      images.map(async (image) => ({
        ...image,
        url: await ctx.storage.getUrl(image.imageId),
      }))
    );
  },
});

export const getImageRecord = internalQuery({
  args: { imageRecordId: v.id("cropImages") },
  handler: async (ctx, args) => {
    return await ctx.db.get(args.imageRecordId);
  },
});

export const updateImageAnalysisStatus = internalMutation({
  args: {
    imageRecordId: v.id("cropImages"),
    status: v.string(),
  },
  handler: async (ctx, args) => {
    await ctx.db.patch(args.imageRecordId, {
      analysisStatus: args.status,
    });
  },
});

export const updateImageAnalysisResults = internalMutation({
  args: {
    imageRecordId: v.id("cropImages"),
    results: v.object({
      diseaseDetected: v.boolean(),
      diseases: v.array(v.object({
        name: v.string(),
        confidence: v.number(),
        severity: v.string(),
        affectedArea: v.number(),
      })),
      healthScore: v.number(),
      stressLevel: v.string(),
      recommendations: v.array(v.string()),
    }),
  },
  handler: async (ctx, args) => {
    await ctx.db.patch(args.imageRecordId, {
      analysisStatus: "completed",
      analysisResults: args.results,
    });
  },
});
