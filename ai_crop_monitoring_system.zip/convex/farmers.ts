import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

export const createFarmerProfile = mutation({
  args: {
    name: v.string(),
    phone: v.string(),
    location: v.object({
      state: v.string(),
      district: v.string(),
      village: v.string(),
      coordinates: v.object({
        lat: v.number(),
        lng: v.number(),
      }),
    }),
    preferredLanguage: v.string(),
    farmSize: v.number(),
    cropTypes: v.array(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("User not authenticated");
    }

    const existingFarmer = await ctx.db
      .query("farmers")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (existingFarmer) {
      throw new Error("Farmer profile already exists");
    }

    return await ctx.db.insert("farmers", {
      userId,
      ...args,
    });
  },
});

export const getFarmerProfile = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return null;
    }

    return await ctx.db
      .query("farmers")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();
  },
});

export const updateFarmerProfile = mutation({
  args: {
    farmerId: v.id("farmers"),
    name: v.optional(v.string()),
    phone: v.optional(v.string()),
    preferredLanguage: v.optional(v.string()),
    farmSize: v.optional(v.number()),
    cropTypes: v.optional(v.array(v.string())),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("User not authenticated");
    }

    const farmer = await ctx.db.get(args.farmerId);
    if (!farmer || farmer.userId !== userId) {
      throw new Error("Unauthorized");
    }

    const { farmerId, ...updates } = args;
    const filteredUpdates = Object.fromEntries(
      Object.entries(updates).filter(([_, value]) => value !== undefined)
    );

    await ctx.db.patch(args.farmerId, filteredUpdates);
  },
});
