import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  // Farmer profiles
  farmers: defineTable({
    userId: v.id("users"),
    name: v.string(),
    phone: v.string(),
    location: v.object({
      state: v.string(),
      district: v.string(),
      village: v.string(),
      coordinates: v.object({
        lat: v.number(),
        lng: v.number(),
      }),
    }),
    preferredLanguage: v.string(),
    farmSize: v.number(), // in acres
    cropTypes: v.array(v.string()),
  })
    .index("by_user", ["userId"])
    .index("by_location", ["location.state", "location.district"]),

  // Field management
  fields: defineTable({
    farmerId: v.id("farmers"),
    name: v.string(),
    area: v.number(), // in acres
    cropType: v.string(),
    plantingDate: v.number(),
    expectedHarvestDate: v.number(),
    coordinates: v.object({
      lat: v.number(),
      lng: v.number(),
    }),
    soilType: v.string(),
    irrigationType: v.string(),
  })
    .index("by_farmer", ["farmerId"])
    .index("by_crop_type", ["cropType"]),

  // IoT Sensor data
  sensors: defineTable({
    fieldId: v.id("fields"),
    sensorId: v.string(),
    type: v.string(), // "moisture", "temperature", "humidity", "ph", "npk"
    location: v.object({
      lat: v.number(),
      lng: v.number(),
    }),
    isActive: v.boolean(),
    lastReading: v.optional(v.number()),
  })
    .index("by_field", ["fieldId"])
    .index("by_sensor_id", ["sensorId"]),

  // Sensor readings
  sensorReadings: defineTable({
    sensorId: v.id("sensors"),
    fieldId: v.id("fields"),
    timestamp: v.number(),
    value: v.number(),
    unit: v.string(),
    sensorType: v.string(),
  })
    .index("by_sensor", ["sensorId"])
    .index("by_field_and_time", ["fieldId", "timestamp"])
    .index("by_timestamp", ["timestamp"]),

  // Crop images and analysis
  cropImages: defineTable({
    fieldId: v.id("fields"),
    farmerId: v.id("farmers"),
    imageId: v.id("_storage"),
    imageType: v.string(), // "hyperspectral", "multispectral", "rgb"
    captureDate: v.number(),
    analysisStatus: v.string(), // "pending", "processing", "completed", "failed"
    analysisResults: v.optional(v.object({
      diseaseDetected: v.boolean(),
      diseases: v.array(v.object({
        name: v.string(),
        confidence: v.number(),
        severity: v.string(),
        affectedArea: v.number(),
      })),
      healthScore: v.number(),
      stressLevel: v.string(),
      recommendations: v.array(v.string()),
    })),
  })
    .index("by_field", ["fieldId"])
    .index("by_farmer", ["farmerId"])
    .index("by_status", ["analysisStatus"]),

  // Satellite imagery data
  satelliteData: defineTable({
    fieldId: v.id("fields"),
    source: v.string(), // "sentinel", "landsat"
    imageDate: v.number(),
    cloudCover: v.number(),
    ndviValue: v.number(),
    eviValue: v.number(),
    imageUrl: v.string(),
    analysisResults: v.optional(v.object({
      vegetationHealth: v.string(),
      waterStress: v.boolean(),
      growthStage: v.string(),
    })),
  })
    .index("by_field", ["fieldId"])
    .index("by_date", ["imageDate"]),

  // Alerts and notifications
  alerts: defineTable({
    farmerId: v.id("farmers"),
    fieldId: v.id("fields"),
    type: v.string(), // "irrigation", "disease", "weather", "harvest"
    severity: v.string(), // "low", "medium", "high", "critical"
    title: v.string(),
    message: v.string(),
    isRead: v.boolean(),
    isResolved: v.boolean(),
    createdAt: v.number(),
    resolvedAt: v.optional(v.number()),
    actionRequired: v.optional(v.object({
      type: v.string(), // "irrigation", "treatment", "inspection"
      parameters: v.optional(v.object({
        duration: v.optional(v.number()),
        amount: v.optional(v.number()),
      })),
    })),
  })
    .index("by_farmer", ["farmerId"])
    .index("by_field", ["fieldId"])
    .index("by_status", ["isRead", "isResolved"])
    .index("by_severity", ["severity"]),

  // Irrigation control
  irrigationSystems: defineTable({
    fieldId: v.id("fields"),
    systemId: v.string(),
    type: v.string(), // "drip", "sprinkler", "flood"
    isActive: v.boolean(),
    currentStatus: v.string(), // "off", "running", "scheduled"
    flowRate: v.number(), // liters per minute
    lastActivated: v.optional(v.number()),
    totalWaterUsed: v.number(), // in liters
  })
    .index("by_field", ["fieldId"])
    .index("by_system_id", ["systemId"]),

  // Irrigation logs
  irrigationLogs: defineTable({
    systemId: v.id("irrigationSystems"),
    fieldId: v.id("fields"),
    startTime: v.number(),
    endTime: v.optional(v.number()),
    duration: v.optional(v.number()), // in minutes
    waterAmount: v.optional(v.number()), // in liters
    triggerType: v.string(), // "manual", "scheduled", "sensor", "ai"
    triggeredBy: v.optional(v.string()),
  })
    .index("by_system", ["systemId"])
    .index("by_field", ["fieldId"])
    .index("by_date", ["startTime"]),

  // Weather data
  weatherData: defineTable({
    location: v.object({
      lat: v.number(),
      lng: v.number(),
    }),
    timestamp: v.number(),
    temperature: v.number(),
    humidity: v.number(),
    rainfall: v.number(),
    windSpeed: v.number(),
    pressure: v.number(),
    forecast: v.optional(v.array(v.object({
      date: v.number(),
      temperature: v.object({
        min: v.number(),
        max: v.number(),
      }),
      humidity: v.number(),
      rainfall: v.number(),
      conditions: v.string(),
    }))),
  })
    .index("by_location_and_time", ["location.lat", "location.lng", "timestamp"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
