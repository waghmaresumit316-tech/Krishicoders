import { mutation, query, internalMutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

export const startIrrigation = mutation({
  args: {
    fieldId: v.id("fields"),
    duration: v.number(), // in minutes
    systemType: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("User not authenticated");
    }

    const field = await ctx.db.get(args.fieldId);
    if (!field) {
      throw new Error("Field not found");
    }

    const farmer = await ctx.db.get(field.farmerId);
    if (!farmer || farmer.userId !== userId) {
      throw new Error("Unauthorized");
    }

    // Find irrigation system for this field
    const irrigationSystem = await ctx.db
      .query("irrigationSystems")
      .withIndex("by_field", (q) => q.eq("fieldId", args.fieldId))
      .first();

    if (!irrigationSystem) {
      throw new Error("No irrigation system found for this field");
    }

    if (irrigationSystem.currentStatus === "running") {
      throw new Error("Irrigation system is already running");
    }

    // Start irrigation
    await ctx.db.patch(irrigationSystem._id, {
      currentStatus: "running",
      lastActivated: Date.now(),
    });

    // Create irrigation log
    const logId = await ctx.db.insert("irrigationLogs", {
      systemId: irrigationSystem._id,
      fieldId: args.fieldId,
      startTime: Date.now(),
      triggerType: "manual",
      triggeredBy: farmer.name,
    });

    // Schedule automatic stop
    await ctx.scheduler.runAfter(
      args.duration * 60 * 1000, // convert minutes to milliseconds
      "irrigation:stopIrrigation" as any,
      {
        systemId: irrigationSystem._id,
        logId: logId,
        duration: args.duration,
      }
    );

    return { success: true, message: `Irrigation started for ${args.duration} minutes` };
  },
});

export const stopIrrigation = mutation({
  args: { fieldId: v.id("fields") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("User not authenticated");
    }

    const field = await ctx.db.get(args.fieldId);
    if (!field) {
      throw new Error("Field not found");
    }

    const farmer = await ctx.db.get(field.farmerId);
    if (!farmer || farmer.userId !== userId) {
      throw new Error("Unauthorized");
    }

    const irrigationSystem = await ctx.db
      .query("irrigationSystems")
      .withIndex("by_field", (q) => q.eq("fieldId", args.fieldId))
      .first();

    if (!irrigationSystem) {
      throw new Error("No irrigation system found");
    }

    if (irrigationSystem.currentStatus !== "running") {
      throw new Error("Irrigation system is not running");
    }

    // Stop irrigation
    await ctx.db.patch(irrigationSystem._id, {
      currentStatus: "off",
    });

    // Update the latest log entry
    const latestLog = await ctx.db
      .query("irrigationLogs")
      .withIndex("by_system", (q) => q.eq("systemId", irrigationSystem._id))
      .order("desc")
      .first();

    if (latestLog && !latestLog.endTime) {
      const duration = Math.floor((Date.now() - latestLog.startTime) / (1000 * 60));
      const waterAmount = duration * irrigationSystem.flowRate;

      await ctx.db.patch(latestLog._id, {
        endTime: Date.now(),
        duration: duration,
        waterAmount: waterAmount,
      });

      // Update total water used
      await ctx.db.patch(irrigationSystem._id, {
        totalWaterUsed: irrigationSystem.totalWaterUsed + waterAmount,
      });
    }

    return { success: true, message: "Irrigation stopped" };
  },
});

export const getIrrigationStatus = query({
  args: { fieldId: v.id("fields") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return null;
    }

    const field = await ctx.db.get(args.fieldId);
    if (!field) {
      return null;
    }

    const farmer = await ctx.db.get(field.farmerId);
    if (!farmer || farmer.userId !== userId) {
      return null;
    }

    const irrigationSystem = await ctx.db
      .query("irrigationSystems")
      .withIndex("by_field", (q) => q.eq("fieldId", args.fieldId))
      .first();

    if (!irrigationSystem) {
      return null;
    }

    const recentLogs = await ctx.db
      .query("irrigationLogs")
      .withIndex("by_system", (q) => q.eq("systemId", irrigationSystem._id))
      .order("desc")
      .take(5);

    return {
      system: irrigationSystem,
      recentLogs: recentLogs,
    };
  },
});
