import React, { useState } from "react";
import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { useLanguage } from "../contexts/LanguageContext";
import { FieldsTab } from "./FieldsTab";
import { SensorsTab } from "./SensorsTab";
import { AlertsTab } from "./AlertsTab";
import { CropHealthTab } from "./CropHealthTab";
import { IrrigationTab } from "./IrrigationTab";

interface DashboardProps {
  farmer: any;
}

export function Dashboard({ farmer }: DashboardProps) {
  const { t } = useLanguage();
  const [activeTab, setActiveTab] = useState("fields");
  const fields = useQuery(api.fields.getFields) || [];
  const alerts = useQuery(api.alerts.getAlerts, { unreadOnly: true }) || [];

  const tabs = [
    { id: "fields", label: t("fields"), icon: "🌾", count: fields.length },
    { id: "sensors", label: t("sensors"), icon: "📡" },
    { id: "cropHealth", label: t("cropHealth"), icon: "🔬" },
    { id: "irrigation", label: t("irrigation"), icon: "💧" },
    { id: "alerts", label: t("alerts"), icon: "🚨", count: alerts.length },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Welcome Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">
                Welcome back, {farmer.name}! 👋
              </h1>
              <p className="text-gray-600">
                {farmer.location.village}, {farmer.location.district}, {farmer.location.state}
              </p>
            </div>
            <div className="text-right">
              <p className="text-sm text-gray-500">Farm Size</p>
              <p className="text-xl font-semibold text-green-600">{farmer.farmSize} acres</p>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <div className="p-2 bg-green-100 rounded-lg">
                <span className="text-2xl">🌾</span>
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Total Fields</p>
                <p className="text-2xl font-bold text-gray-900">{fields.length}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <div className="p-2 bg-blue-100 rounded-lg">
                <span className="text-2xl">📡</span>
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Active Sensors</p>
                <p className="text-2xl font-bold text-gray-900">12</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <div className="p-2 bg-yellow-100 rounded-lg">
                <span className="text-2xl">🚨</span>
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Active Alerts</p>
                <p className="text-2xl font-bold text-gray-900">{alerts.length}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <div className="p-2 bg-green-100 rounded-lg">
                <span className="text-2xl">💧</span>
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Water Usage</p>
                <p className="text-2xl font-bold text-gray-900">1,250L</p>
              </div>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="bg-white rounded-lg shadow mb-6">
          <div className="border-b border-gray-200">
            <nav className="flex space-x-8 px-6">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`py-4 px-1 border-b-2 font-medium text-sm flex items-center space-x-2 ${
                    activeTab === tab.id
                      ? "border-green-500 text-green-600"
                      : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                  }`}
                >
                  <span>{tab.icon}</span>
                  <span>{tab.label}</span>
                  {tab.count !== undefined && (
                    <span className="bg-gray-100 text-gray-600 py-0.5 px-2 rounded-full text-xs">
                      {tab.count}
                    </span>
                  )}
                </button>
              ))}
            </nav>
          </div>

          {/* Tab Content */}
          <div className="p-6">
            {activeTab === "fields" && <FieldsTab />}
            {activeTab === "sensors" && <SensorsTab />}
            {activeTab === "cropHealth" && <CropHealthTab />}
            {activeTab === "irrigation" && <IrrigationTab />}
            {activeTab === "alerts" && <AlertsTab />}
          </div>
        </div>
      </div>
    </div>
  );
}
