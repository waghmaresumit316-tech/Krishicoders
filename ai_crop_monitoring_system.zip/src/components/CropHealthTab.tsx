import React, { useState, useRef } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { useLanguage } from "../contexts/LanguageContext";
import { toast } from "sonner";

export function CropHealthTab() {
  const { t } = useLanguage();
  const fields = useQuery(api.fields.getFields) || [];
  const [selectedField, setSelectedField] = useState<string>("");
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const generateUploadUrl = useMutation(api.images.generateUploadUrl);
  const saveCropImage = useMutation(api.images.saveCropImage);
  const cropImages = useQuery(
    api.images.getCropImages,
    selectedField ? { fieldId: selectedField as any } : "skip"
  );

  const handleImageCapture = async () => {
    try {
      // Request camera access
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { 
          facingMode: 'environment', // Use back camera on mobile
          width: { ideal: 1920 },
          height: { ideal: 1080 }
        } 
      });
      
      // Create video element to show camera feed
      const video = document.createElement('video');
      video.srcObject = stream;
      video.autoplay = true;
      video.playsInline = true;
      
      // Create modal for camera interface
      const modal = document.createElement('div');
      modal.className = 'fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50';
      modal.innerHTML = `
        <div class="bg-white rounded-lg p-4 max-w-md w-full mx-4">
          <h3 class="text-lg font-semibold mb-4 text-center">Capture Crop Image</h3>
          <div class="relative">
            <video id="camera-video" class="w-full rounded-lg" autoplay playsinline></video>
            <canvas id="camera-canvas" class="hidden"></canvas>
          </div>
          <div class="flex justify-center space-x-4 mt-4">
            <button id="capture-btn" class="bg-green-600 text-white px-6 py-2 rounded-md hover:bg-green-700">
              📸 Capture
            </button>
            <button id="cancel-btn" class="bg-gray-600 text-white px-6 py-2 rounded-md hover:bg-gray-700">
              Cancel
            </button>
          </div>
        </div>
      `;
      
      document.body.appendChild(modal);
      const modalVideo = modal.querySelector('#camera-video') as HTMLVideoElement;
      const canvas = modal.querySelector('#camera-canvas') as HTMLCanvasElement;
      const captureBtn = modal.querySelector('#capture-btn') as HTMLButtonElement;
      const cancelBtn = modal.querySelector('#cancel-btn') as HTMLButtonElement;
      
      modalVideo.srcObject = stream;
      
      const cleanup = () => {
        stream.getTracks().forEach(track => track.stop());
        document.body.removeChild(modal);
      };
      
      cancelBtn.onclick = cleanup;
      
      captureBtn.onclick = async () => {
        try {
          setIsUploading(true);
          
          // Capture image from video
          const context = canvas.getContext('2d')!;
          canvas.width = modalVideo.videoWidth;
          canvas.height = modalVideo.videoHeight;
          context.drawImage(modalVideo, 0, 0);
          
          // Convert to blob
          canvas.toBlob(async (blob) => {
            if (!blob) {
              toast.error("Failed to capture image");
              return;
            }
            
            try {
              // Upload to Convex
              const uploadUrl = await generateUploadUrl();
              const result = await fetch(uploadUrl, {
                method: "POST",
                headers: { "Content-Type": blob.type },
                body: blob,
              });
              
              if (!result.ok) {
                throw new Error("Upload failed");
              }
              
              const { storageId } = await result.json();
              
              // Save image record
              await saveCropImage({
                fieldId: selectedField as any,
                imageId: storageId,
                imageType: "rgb",
              });
              
              toast.success("Image captured and uploaded successfully!");
              cleanup();
            } catch (error) {
              console.error("Upload error:", error);
              toast.error("Failed to upload image");
            } finally {
              setIsUploading(false);
            }
          }, 'image/jpeg', 0.8);
          
        } catch (error) {
          console.error("Capture error:", error);
          toast.error("Failed to capture image");
          setIsUploading(false);
        }
      };
      
    } catch (error) {
      console.error("Camera access error:", error);
      toast.error("Camera access denied. Please allow camera access and try again.");
    }
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file || !selectedField) return;

    setIsUploading(true);
    try {
      const uploadUrl = await generateUploadUrl();
      const result = await fetch(uploadUrl, {
        method: "POST",
        headers: { "Content-Type": file.type },
        body: file,
      });

      if (!result.ok) {
        throw new Error("Upload failed");
      }

      const { storageId } = await result.json();

      await saveCropImage({
        fieldId: selectedField as any,
        imageId: storageId,
        imageType: "rgb",
      });

      toast.success("Image uploaded successfully!");
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    } catch (error) {
      console.error("Upload error:", error);
      toast.error("Failed to upload image");
    } finally {
      setIsUploading(false);
    }
  };

  const getAnalysisStatusColor = (status: string) => {
    switch (status) {
      case "completed": return "text-green-600 bg-green-100";
      case "processing": return "text-yellow-600 bg-yellow-100";
      case "failed": return "text-red-600 bg-red-100";
      default: return "text-gray-600 bg-gray-100";
    }
  };

  const getHealthScoreColor = (score: number) => {
    if (score >= 80) return "text-green-600";
    if (score >= 60) return "text-yellow-600";
    return "text-red-600";
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-semibold text-gray-900">{t("cropHealth")}</h2>
        <div className="flex items-center space-x-4">
          <select
            value={selectedField}
            onChange={(e) => setSelectedField(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
          >
            <option value="">Select Field</option>
            {fields.map((field) => (
              <option key={field._id} value={field._id}>
                {field.name} ({field.cropType})
              </option>
            ))}
          </select>
        </div>
      </div>

      {!selectedField ? (
        <div className="text-center py-12">
          <div className="text-6xl mb-4">🔬</div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">Select a field for crop health analysis</h3>
          <p className="text-gray-600">Choose a field from the dropdown above to start monitoring</p>
        </div>
      ) : (
        <div className="space-y-6">
          {/* Image Upload Section */}
          <div className="bg-white border border-gray-200 rounded-lg p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Capture or Upload Crop Images</h3>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <button
                onClick={handleImageCapture}
                disabled={isUploading}
                className="flex-1 bg-green-600 text-white px-4 py-3 rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 disabled:opacity-50 flex items-center justify-center space-x-2"
              >
                <span>📸</span>
                <span>{isUploading ? "Processing..." : "Capture with Camera"}</span>
              </button>
              
              <div className="flex-1">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleFileUpload}
                  disabled={isUploading}
                  className="hidden"
                />
                <button
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isUploading}
                  className="w-full bg-blue-600 text-white px-4 py-3 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50 flex items-center justify-center space-x-2"
                >
                  <span>📁</span>
                  <span>{isUploading ? "Uploading..." : "Upload from Gallery"}</span>
                </button>
              </div>
            </div>

            <div className="mt-4 p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                <span className="text-blue-600">💡</span>
                <h4 className="font-medium text-blue-900">Tips for Best Results</h4>
              </div>
              <ul className="text-blue-800 text-sm space-y-1">
                <li>• Take photos in good lighting conditions</li>
                <li>• Focus on leaves, stems, and any visible issues</li>
                <li>• Capture multiple angles of affected areas</li>
                <li>• Ensure images are clear and not blurry</li>
              </ul>
            </div>
          </div>

          {/* Analysis Results */}
          {cropImages && cropImages.length > 0 && (
            <div className="bg-white border border-gray-200 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Analysis Results</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {cropImages.map((image) => (
                  <div key={image._id} className="border border-gray-200 rounded-lg overflow-hidden">
                    {image.url && (
                      <img
                        src={image.url}
                        alt="Crop analysis"
                        className="w-full h-48 object-cover"
                      />
                    )}
                    
                    <div className="p-4">
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-sm text-gray-500">
                          {new Date(image.captureDate).toLocaleDateString()}
                        </span>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${getAnalysisStatusColor(image.analysisStatus)}`}>
                          {image.analysisStatus}
                        </span>
                      </div>
                      
                      {image.analysisResults && (
                        <div className="space-y-2">
                          <div className="flex justify-between items-center">
                            <span className="text-sm font-medium">Health Score:</span>
                            <span className={`font-bold ${getHealthScoreColor(image.analysisResults.healthScore)}`}>
                              {image.analysisResults.healthScore}/100
                            </span>
                          </div>
                          
                          <div className="flex justify-between items-center">
                            <span className="text-sm font-medium">Stress Level:</span>
                            <span className="text-sm">{image.analysisResults.stressLevel}</span>
                          </div>
                          
                          {image.analysisResults.diseaseDetected && (
                            <div className="mt-2 p-2 bg-red-50 border border-red-200 rounded">
                              <div className="text-sm font-medium text-red-800 mb-1">Diseases Detected:</div>
                              {image.analysisResults.diseases.map((disease, idx) => (
                                <div key={idx} className="text-xs text-red-700">
                                  {disease.name} ({Math.round(disease.confidence * 100)}% confidence)
                                </div>
                              ))}
                            </div>
                          )}
                          
                          {image.analysisResults.recommendations.length > 0 && (
                            <div className="mt-2">
                              <div className="text-sm font-medium text-gray-700 mb-1">Recommendations:</div>
                              <ul className="text-xs text-gray-600 space-y-1">
                                {image.analysisResults.recommendations.map((rec, idx) => (
                                  <li key={idx}>• {rec}</li>
                                ))}
                              </ul>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {cropImages && cropImages.length === 0 && (
            <div className="text-center py-12">
              <div className="text-6xl mb-4">📸</div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">No images uploaded yet</h3>
              <p className="text-gray-600">Start by capturing or uploading crop images for AI analysis</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
