import React, { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { useLanguage } from "../contexts/LanguageContext";
import { toast } from "sonner";

export function IrrigationTab() {
  const { t } = useLanguage();
  const fields = useQuery(api.fields.getFields) || [];
  const [selectedField, setSelectedField] = useState<string>("");
  const [duration, setDuration] = useState(30);
  
  const startIrrigation = useMutation(api.irrigation.startIrrigation);
  const stopIrrigation = useMutation(api.irrigation.stopIrrigation);
  
  const irrigationStatus = useQuery(
    api.irrigation.getIrrigationStatus,
    selectedField ? { fieldId: selectedField as any } : "skip"
  );

  const handleStartIrrigation = async () => {
    if (!selectedField) return;
    
    try {
      await startIrrigation({
        fieldId: selectedField as any,
        duration: duration,
      });
      toast.success(`Irrigation started for ${duration} minutes`);
    } catch (error) {
      toast.error("Failed to start irrigation");
    }
  };

  const handleStopIrrigation = async () => {
    if (!selectedField) return;
    
    try {
      await stopIrrigation({ fieldId: selectedField as any });
      toast.success("Irrigation stopped");
    } catch (error) {
      toast.error("Failed to stop irrigation");
    }
  };

  const isRunning = irrigationStatus?.system?.currentStatus === "running";

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-semibold text-gray-900">{t("irrigation")}</h2>
        <div className="flex items-center space-x-4">
          <select
            value={selectedField}
            onChange={(e) => setSelectedField(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
          >
            <option value="">Select Field</option>
            {fields.map((field) => (
              <option key={field._id} value={field._id}>
                {field.name} ({field.cropType})
              </option>
            ))}
          </select>
        </div>
      </div>

      {!selectedField ? (
        <div className="text-center py-12">
          <div className="text-6xl mb-4">💧</div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">Select a field for irrigation control</h3>
          <p className="text-gray-600">Choose a field from the dropdown above to manage irrigation</p>
        </div>
      ) : (
        <div className="space-y-6">
          {/* Irrigation Control Panel */}
          <div className="bg-white border border-gray-200 rounded-lg p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Irrigation Control</h3>
            
            {irrigationStatus?.system ? (
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-gray-50 rounded-lg p-4">
                    <div className="text-sm text-gray-600">Status</div>
                    <div className={`text-lg font-semibold ${
                      isRunning ? "text-green-600" : "text-gray-900"
                    }`}>
                      {isRunning ? "Running" : "Stopped"}
                    </div>
                  </div>
                  
                  <div className="bg-gray-50 rounded-lg p-4">
                    <div className="text-sm text-gray-600">System Type</div>
                    <div className="text-lg font-semibold text-gray-900">
                      {irrigationStatus.system.type}
                    </div>
                  </div>
                  
                  <div className="bg-gray-50 rounded-lg p-4">
                    <div className="text-sm text-gray-600">Flow Rate</div>
                    <div className="text-lg font-semibold text-gray-900">
                      {irrigationStatus.system.flowRate} L/min
                    </div>
                  </div>
                </div>

                <div className="flex items-center space-x-4">
                  {!isRunning ? (
                    <>
                      <div className="flex items-center space-x-2">
                        <label className="text-sm font-medium text-gray-700">
                          {t("duration")}:
                        </label>
                        <input
                          type="number"
                          min="1"
                          max="120"
                          value={duration}
                          onChange={(e) => setDuration(parseInt(e.target.value))}
                          className="w-20 px-2 py-1 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                        />
                        <span className="text-sm text-gray-600">minutes</span>
                      </div>
                      <button
                        onClick={handleStartIrrigation}
                        className="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500"
                      >
                        {t("startIrrigation")}
                      </button>
                    </>
                  ) : (
                    <button
                      onClick={handleStopIrrigation}
                      className="bg-red-600 text-white px-4 py-2 rounded-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500"
                    >
                      {t("stopIrrigation")}
                    </button>
                  )}
                </div>
              </div>
            ) : (
              <div className="text-center py-8">
                <div className="text-4xl mb-2">⚠️</div>
                <p className="text-gray-600">No irrigation system found for this field</p>
              </div>
            )}
          </div>

          {/* Recent Irrigation Logs */}
          {irrigationStatus?.recentLogs && irrigationStatus.recentLogs.length > 0 && (
            <div className="bg-white border border-gray-200 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Irrigation History</h3>
              <div className="space-y-3">
                {irrigationStatus.recentLogs.map((log) => (
                  <div key={log._id} className="flex justify-between items-center py-2 border-b border-gray-100">
                    <div>
                      <div className="text-sm font-medium text-gray-900">
                        {new Date(log.startTime).toLocaleString()}
                      </div>
                      <div className="text-xs text-gray-500">
                        Triggered by: {log.triggeredBy || log.triggerType}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-medium text-gray-900">
                        {log.duration ? `${log.duration} min` : "Running..."}
                      </div>
                      <div className="text-xs text-gray-500">
                        {log.waterAmount ? `${log.waterAmount}L` : ""}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Smart Irrigation Info */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <div className="flex items-center space-x-2 mb-2">
              <span className="text-blue-600">💡</span>
              <h4 className="font-medium text-blue-900">Smart Irrigation Features</h4>
            </div>
            <p className="text-blue-800 text-sm">
              Irrigation can be triggered manually, by schedule, or automatically based on soil moisture sensors. 
              The system optimizes water usage while ensuring optimal crop health.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
