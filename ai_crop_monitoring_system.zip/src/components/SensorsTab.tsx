import React from "react";
import { useLanguage } from "../contexts/LanguageContext";

export function SensorsTab() {
  const { t } = useLanguage();

  // Mock sensor data - replace with real data from Convex
  const sensorData = [
    { id: 1, type: "Moisture", value: 65, unit: "%", status: "normal", lastReading: "2 min ago" },
    { id: 2, type: "Temperature", value: 28, unit: "°C", status: "normal", lastReading: "2 min ago" },
    { id: 3, type: "Humidity", value: 72, unit: "%", status: "normal", lastReading: "3 min ago" },
    { id: 4, type: "pH Level", value: 6.8, unit: "pH", status: "normal", lastReading: "5 min ago" },
    { id: 5, type: "NPK", value: 85, unit: "ppm", status: "low", lastReading: "1 min ago" },
    { id: 6, type: "Light", value: 45000, unit: "lux", status: "normal", lastReading: "1 min ago" },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "normal": return "text-green-600 bg-green-100";
      case "low": return "text-yellow-600 bg-yellow-100";
      case "high": return "text-red-600 bg-red-100";
      default: return "text-gray-600 bg-gray-100";
    }
  };

  const getSensorIcon = (type: string) => {
    switch (type) {
      case "Moisture": return "💧";
      case "Temperature": return "🌡️";
      case "Humidity": return "💨";
      case "pH Level": return "⚗️";
      case "NPK": return "🧪";
      case "Light": return "☀️";
      default: return "📡";
    }
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-semibold text-gray-900">{t("sensors")}</h2>
        <div className="flex items-center space-x-2">
          <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
          <span className="text-sm text-gray-600">Live Data</span>
        </div>
      </div>

      {/* Sensor Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {sensorData.map((sensor) => (
          <div key={sensor.id} className="bg-white border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-3">
                <span className="text-2xl">{getSensorIcon(sensor.type)}</span>
                <div>
                  <h3 className="font-semibold text-gray-900">{sensor.type}</h3>
                  <p className="text-sm text-gray-500">Sensor #{sensor.id}</p>
                </div>
              </div>
              <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(sensor.status)}`}>
                {sensor.status}
              </span>
            </div>

            <div className="mb-4">
              <div className="flex items-baseline space-x-2">
                <span className="text-3xl font-bold text-gray-900">{sensor.value}</span>
                <span className="text-lg text-gray-600">{sensor.unit}</span>
              </div>
            </div>

            <div className="flex justify-between items-center text-sm text-gray-500">
              <span>Last reading</span>
              <span>{sensor.lastReading}</span>
            </div>

            {/* Progress bar for percentage values */}
            {sensor.unit === "%" && (
              <div className="mt-3">
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-green-600 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${Math.min(sensor.value, 100)}%` }}
                  ></div>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Sensor History Chart Placeholder */}
      <div className="mt-8 bg-white border border-gray-200 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Sensor Trends (Last 24 Hours)</h3>
        <div className="h-64 bg-gray-50 rounded-lg flex items-center justify-center">
          <div className="text-center">
            <div className="text-4xl mb-2">📊</div>
            <p className="text-gray-600">Sensor trend charts will be displayed here</p>
            <p className="text-sm text-gray-500">Real-time data visualization coming soon</p>
          </div>
        </div>
      </div>

      {/* Sensor Management */}
      <div className="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-4">
        <div className="flex items-center space-x-2 mb-2">
          <span className="text-blue-600">ℹ️</span>
          <h4 className="font-medium text-blue-900">IoT Sensor Integration</h4>
        </div>
        <p className="text-blue-800 text-sm">
          Connect your IoT sensors to automatically receive real-time data. 
          Sensors will send data via WiFi/LoRaWAN to our cloud platform for instant monitoring and alerts.
        </p>
      </div>
    </div>
  );
}
