import React from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { useLanguage } from "../contexts/LanguageContext";
import { toast } from "sonner";

export function AlertsTab() {
  const { t } = useLanguage();
  const alerts = useQuery(api.alerts.getAlerts, {}) || [];
  const markAsRead = useMutation(api.alerts.markAlertAsRead);
  const resolveAlert = useMutation(api.alerts.resolveAlert);

  const handleMarkAsRead = async (alertId: string) => {
    try {
      await markAsRead({ alertId: alertId as any });
      toast.success("Alert marked as read");
    } catch (error) {
      toast.error("Failed to mark alert as read");
    }
  };

  const handleResolve = async (alertId: string) => {
    try {
      await resolveAlert({ alertId: alertId as any });
      toast.success("Alert resolved");
    } catch (error) {
      toast.error("Failed to resolve alert");
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "critical": return "text-red-600 bg-red-100 border-red-200";
      case "high": return "text-orange-600 bg-orange-100 border-orange-200";
      case "medium": return "text-yellow-600 bg-yellow-100 border-yellow-200";
      case "low": return "text-blue-600 bg-blue-100 border-blue-200";
      default: return "text-gray-600 bg-gray-100 border-gray-200";
    }
  };

  const getAlertIcon = (type: string) => {
    switch (type) {
      case "disease": return "🦠";
      case "irrigation": return "💧";
      case "weather": return "🌤️";
      case "harvest": return "🌾";
      default: return "⚠️";
    }
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-semibold text-gray-900">{t("alerts")}</h2>
        <div className="text-sm text-gray-500">
          {alerts.filter(a => !a.isRead).length} unread alerts
        </div>
      </div>

      <div className="space-y-4">
        {alerts.map((alert) => (
          <div
            key={alert._id}
            className={`border rounded-lg p-4 ${getSeverityColor(alert.severity)} ${
              !alert.isRead ? "border-l-4" : ""
            }`}
          >
            <div className="flex items-start justify-between">
              <div className="flex items-start space-x-3">
                <span className="text-2xl">{getAlertIcon(alert.type)}</span>
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-1">
                    <h3 className="font-semibold text-gray-900">{alert.title}</h3>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getSeverityColor(alert.severity)}`}>
                      {alert.severity}
                    </span>
                    {!alert.isRead && (
                      <span className="w-2 h-2 bg-blue-500 rounded-full"></span>
                    )}
                  </div>
                  <p className="text-gray-700 mb-2">{alert.message}</p>
                  <div className="text-sm text-gray-500">
                    {new Date(alert.createdAt).toLocaleString()}
                  </div>
                </div>
              </div>
              
              <div className="flex space-x-2">
                {!alert.isRead && (
                  <button
                    onClick={() => handleMarkAsRead(alert._id)}
                    className="text-sm text-blue-600 hover:text-blue-800"
                  >
                    {t("markAsRead")}
                  </button>
                )}
                {!alert.isResolved && (
                  <button
                    onClick={() => handleResolve(alert._id)}
                    className="text-sm text-green-600 hover:text-green-800"
                  >
                    {t("resolve")}
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {alerts.length === 0 && (
        <div className="text-center py-12">
          <div className="text-6xl mb-4">🔔</div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">No alerts</h3>
          <p className="text-gray-600">All systems are running smoothly</p>
        </div>
      )}
    </div>
  );
}
